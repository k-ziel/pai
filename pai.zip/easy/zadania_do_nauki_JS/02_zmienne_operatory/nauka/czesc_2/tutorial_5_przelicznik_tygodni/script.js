// Math.floor i %
