// Wpisz wzór poprawnie
